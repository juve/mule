#!/usr/bin/env python

import sys
if sys.version_info[0] == 2 :
  import setup2
else :  # >= Python 3.0
  import setup3

